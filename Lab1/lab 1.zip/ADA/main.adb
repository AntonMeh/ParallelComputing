with Ada.Text_IO;         use Ada.Text_IO;
with Ada.Integer_Text_IO; use Ada.Integer_Text_IO;
with Ada.Numerics.Discrete_Random;

procedure Main is

   subtype Delay_Range is Integer range 1000 .. 9999;
   package Random_Delay is new Ada.Numerics.Discrete_Random(Delay_Range);
   Gen : Random_Delay.Generator;

   Max_Threads : constant := 100;
   Quantity    : Integer;

   Stop_Flags : array (1 .. Max_Threads) of Boolean := (others => False);
   Delays     : array (1 .. Max_Threads) of Integer;

   task type Calculator (Id : Integer; Step : Integer) is
      entry WaitReady;
   end Calculator;

   task body Calculator is
      Sum   : Long_Long_Integer := 0;
      Count : Long_Long_Integer := 0;
   begin
      accept WaitReady;
      loop
         exit when Stop_Flags (Id);
         Sum   := Sum + Long_Long_Integer (Step);
         Count := Count + 1;
      end loop;
      Put_Line ("Thread" & Integer'Image (Id) &
                " finished  sum =" & Long_Long_Integer'Image (Sum) &
                "  Quantity =" & Long_Long_Integer'Image (Count));
   end Calculator;

   task type Stopper (N : Integer);

   task body Stopper is
      Order   : array (1 .. N) of Integer;
      Tmp     : Integer;
      Elapsed : Integer := 0;
      Wait    : Integer;
   begin
      for I in 1 .. N loop
         Order (I) := I;
      end loop;

      for I in 1 .. N - 1 loop
         for J in 1 .. N - I loop
            if Delays (Order (J)) > Delays (Order (J + 1)) then
               Tmp           := Order (J);
               Order (J)     := Order (J + 1);
               Order (J + 1) := Tmp;
            end if;
         end loop;
      end loop;

      for I in 1 .. N loop
         Wait    := Delays (Order (I)) - Elapsed;
         delay Duration (Float (Wait) / 1000.0);
         Elapsed := Elapsed + Wait;

         Stop_Flags (Order (I)) := True;
         Put_Line ("[Controller] Thread" & Integer'Image (Order (I)) &
                   " stop signal sent at" & Integer'Image (Elapsed) & " ms");
      end loop;
   end Stopper;

begin
   Random_Delay.Reset (Gen);

   Put ("Write quantity of threads: ");
   Get (Quantity);

   for I in 1 .. Quantity loop
      Delays (I) := Random_Delay.Random (Gen);
      Put_Line ("Thread" & Integer'Image (I) &
                " will be stopped after" & Integer'Image (Delays (I)) & " ms");
   end loop;

   declare
      type Calc_Access is access Calculator;
      Workers : array (1 .. Quantity) of Calc_Access;
   begin
      for I in 1 .. Quantity loop
         Workers (I) := new Calculator (Id => I, Step => I);
      end loop;

      for I in 1 .. Quantity loop
         Workers (I).WaitReady;
      end loop;

      declare
         Control : Stopper (Quantity);
      begin
         null;
      end;
   end;

end Main;